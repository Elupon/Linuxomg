#!/usr/bin/env bash
iso_name="dolboeb-os"
iso_label="DOLBOEB_$(date +%Y%m)"
iso_publisher="Dolboeb OS meme project"
iso_application="Dolboeb OS — Arch-based meme live system"
iso_version="1.0"
install_dir="dolboeb"
buildmodes=('iso')
bootmodes=('bios.syslinux' 'uefi-x64.systemd-boot')
arch="x86_64"
airootfs_image_type="squashfs"
file_permissions=(
  ["/etc/shadow"]="0:0:400"
  ["/usr/local/bin/dolboeb-meltdown"]="0:0:755"
)
