# УБЛЮДСКАЯ ОС 1.0 — Debian Edition

Проект Live ISO на базе Debian 13 Trixie и KDE Plasma (amd64).

## Состав
- Debian Live / live-build configuration
- KDE Plasma desktop and useful applications
- Firmware packages from non-free-firmware
- Branding (`os-release`, hostname, welcome file)
- Basic Plymouth theme stub
- Custom wallpaper asset in `assets/`, also installed under `/usr/share/backgrounds/`

## Сборка
Используется GitHub Actions workflow из `.github/workflows/build-iso.yml`
репозитория. Workflow должен распаковать этот архив в рабочую директорию,
затем выполнить `lb config` и `lb build`.

## Важно
Это исходный проект конфигурации, а не готовый ISO. Первую сборку нужно
проверить в GitHub Actions и загрузить ISO в QEMU. Calamares включён в
список пакетов, но установщик ещё требует отдельной настройки и тестирования.
