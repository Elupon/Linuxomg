# УБЛЮДСКАЯ ОС 1.0 — Debian Edition

Проект Live Linux на базе **Debian 13 Trixie + KDE Plasma**, архитектура x86_64.

## Сборка ISO

1. Добавьте содержимое этого проекта в корень репозитория `Elupon/Linuxomg`.
2. Убедитесь, что файл workflow находится по пути `.github/workflows/build-iso.yml`.
3. Откройте вкладку **Actions** на GitHub.
4. Выберите **Build Ublyudskaya OS ISO** и нажмите **Run workflow**.
5. После успешной сборки скачайте artifact **UblyudskayaOS-ISO**. Внутри будет ISO-файл.

Сборка выполняется в Debian Trixie-контейнере на GitHub Actions. Нужен доступный Docker на runner (стандартный GitHub-hosted Ubuntu runner его предоставляет).

## Запуск в QEMU

Для первого теста выделите системе 4 ГБ RAM и 2 виртуальных CPU. Выберите архитектуру x86_64 и загрузку с CD-ROM/ISO. Для графического интерфейса используйте стандартный VGA/virtio-vga адаптер.

## Что уже включено

- Debian 13 Trixie
- KDE Plasma desktop task
- SDDM
- live-boot / live-config
- NetworkManager
- Firefox ESR, Dolphin, Konsole, Ark, Kate и базовые KDE-приложения
- Брендинг УБЛЮДСКАЯ ОС в системной информации и приветственных сообщениях

## Важно

Это первая базовая сборка. Она создаёт Live ISO без графического установщика. Фирменные обои, полноценная тема KDE, Plymouth splash и установщик будут добавляться отдельными этапами после проверки, что базовый ISO загружается в QEMU.
