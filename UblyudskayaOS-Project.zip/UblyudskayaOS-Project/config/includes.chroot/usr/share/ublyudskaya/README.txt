УБЛЮДСКАЯ ОС 1.0
Debian 13 Trixie + KDE Plasma
Проект: https://github.com/Elupon/Linuxomg
