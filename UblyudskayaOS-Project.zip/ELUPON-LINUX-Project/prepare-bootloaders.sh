#!/usr/bin/env bash
# Run from the extracted project directory on the live-build runner, before lb config.
set -euo pipefail
SOURCE="/usr/share/live/build/bootloaders"
if [[ ! -d "$SOURCE" ]]; then
  echo "live-build bootloader templates not found at $SOURCE; install live-build first." >&2
  exit 1
fi
mkdir -p config/bootloaders
cp -a "$SOURCE"/. config/bootloaders/
# Replace the default vector splash in the ISOLINUX/SYSLINUX templates with ELUPON PNG.
while IFS= read -r -d '' dir; do
  cp -f assets/splash.png "$dir/splash.png"
  rm -f "$dir/splash.svg"
done < <(find config/bootloaders -type f \( -name isolinux.cfg -o -name syslinux.cfg -o -name menu.cfg \) -printf '%h\0' | sort -zu)
# Keep explicit copies for GRUB-based image configurations too.
mkdir -p config/bootloaders/grub-pc config/bootloaders/grub-efi
cp -f assets/splash.png config/bootloaders/grub-pc/splash.png
cp -f assets/splash.png config/bootloaders/grub-efi/splash.png
echo "ELUPON bootloader templates prepared; splash.png replaced."
