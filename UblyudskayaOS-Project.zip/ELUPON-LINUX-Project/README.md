# ELUPON LINUX 1.0

Debian 13 Trixie Live ISO configuration with KDE Plasma (amd64).

Included branding:
- ELUPON LINUX identity in os-release and issue
- E-in-circle SVG/PNG logo
- Three original 1920x1080 wallpapers (blue, midnight, aurora)
- Plymouth script splash with the E logo
- Fastfetch custom E ASCII logo
- KDE `start-here-kde` icon override
- ELUPON LIVE Session live-config identity
- GRUB background configuration
- `uname -a` display wrapper; actual kernel remains Linux

This is a source project archive, not a built ISO. Build with Debian live-build,
then test the resulting ISO in QEMU. KDE may cache panel icons and wallpaper,
so confirm the live session and adjust the Plasma defaults if needed.
