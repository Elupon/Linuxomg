# ELUPON LINUX 1.2

Debian 13 Trixie Live ISO source project with KDE Plasma (amd64), rebranded as ELUPON LINUX.

## Branding included
- ELUPON LINUX identity and release metadata
- Three ELUPON wallpapers; Debian/desktop-base wallpaper packages are purged and bundled background directories are cleaned
- ELUPON wallpaper applied automatically at KDE login
- ELUPON Breeze: branded copy of the upstream SDDM Breeze theme, selected by default
- ELUPON bootloader splash artwork (`splash.png`, 640x480) for the live-build isolinux, grub-pc and grub-efi theme directories
- ELUPON Plymouth script theme with initramfs regeneration in the chroot hook
- ELUPON logo assets for the desktop and About This System/distributor-logo locations
- Fastfetch and OS identity files

## Build notes
This archive contains the source configuration, not a prebuilt ISO. The existing GitHub Actions workflow must unpack this folder and run live-build with the live boot parameters `quiet splash`. For GRUB-based images, pass the splash file through live-build's `--grub-splash` option. The Debian Live ISO default boot menu commonly uses ISOLINUX; its customized `config/bootloaders/isolinux/splash.png` is included.

The SDDM theme copy is made in the chroot hook from the installed upstream Breeze SDDM theme. The ISO still needs to be built and tested in QEMU to verify graphics-driver-specific Plymouth behavior.

Before running `lb config` in CI, run `bash prepare-bootloaders.sh` from this project directory after installing the `live-build` package. This copies the runner's matching Debian live-build bootloader templates into `config/bootloaders`, replaces their `splash.png`, and removes the old SVG splash. For the standard ISO workflow, also configure live kernel parameters with `--bootappend-live "boot=live components quiet splash"`.
